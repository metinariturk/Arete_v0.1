<style>

    .fa-star {
        color: #ffd30e;
        text-shadow: 0 0 1px #545454;

    }

</style>